-- Fix search path for generate_token_number function
DROP FUNCTION IF EXISTS public.generate_token_number(TEXT);

CREATE OR REPLACE FUNCTION public.generate_token_number(service_name TEXT)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  token_count INTEGER;
  token_prefix TEXT;
BEGIN
  token_prefix := UPPER(LEFT(service_name, 3));
  
  SELECT COUNT(*) INTO token_count
  FROM public.tokens t
  JOIN public.services s ON t.service_id = s.id
  WHERE s.name = service_name
  AND DATE(t.created_at) = CURRENT_DATE;
  
  RETURN token_prefix || '-' || TO_CHAR(CURRENT_DATE, 'YYMMDD') || '-' || LPAD((token_count + 1)::TEXT, 4, '0');
END;
$$;