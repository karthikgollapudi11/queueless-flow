-- Create enum for user roles
CREATE TYPE public.app_role AS ENUM ('student', 'admin');

-- Create user_roles table
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, role)
);

-- Create profiles table for additional user info
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  student_id TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create services table
CREATE TABLE public.services (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  slots_per_hour INTEGER DEFAULT 20,
  working_hours_start INTEGER DEFAULT 9,
  working_hours_end INTEGER DEFAULT 17,
  average_duration_minutes INTEGER DEFAULT 15,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create token status enum
CREATE TYPE public.token_status AS ENUM ('pending', 'in_progress', 'completed', 'cancelled');

-- Create tokens table
CREATE TABLE public.tokens (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  token_number TEXT NOT NULL,
  student_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  service_id UUID REFERENCES public.services(id) ON DELETE CASCADE NOT NULL,
  status token_status DEFAULT 'pending',
  slot_time TIMESTAMPTZ NOT NULL,
  estimated_wait_minutes INTEGER,
  issued_at TIMESTAMPTZ DEFAULT now(),
  started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create service_analytics table
CREATE TABLE public.service_analytics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  service_id UUID REFERENCES public.services(id) ON DELETE CASCADE NOT NULL,
  date DATE DEFAULT CURRENT_DATE,
  total_tokens INTEGER DEFAULT 0,
  completed_tokens INTEGER DEFAULT 0,
  average_duration_minutes INTEGER,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(service_id, date)
);

-- Enable RLS
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.service_analytics ENABLE ROW LEVEL SECURITY;

-- Create security definer function to check user role
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
    AND role = _role
  )
$$;

-- RLS Policies for user_roles
CREATE POLICY "Users can view their own role"
  ON public.user_roles FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all roles"
  ON public.user_roles FOR SELECT
  USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for profiles
CREATE POLICY "Users can view their own profile"
  ON public.profiles FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can insert their own profile"
  ON public.profiles FOR INSERT
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "Admins can view all profiles"
  ON public.profiles FOR SELECT
  USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for services
CREATE POLICY "Anyone can view active services"
  ON public.services FOR SELECT
  USING (is_active = true OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can manage services"
  ON public.services FOR ALL
  USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for tokens
CREATE POLICY "Students can view their own tokens"
  ON public.tokens FOR SELECT
  USING (auth.uid() = student_id);

CREATE POLICY "Students can create tokens"
  ON public.tokens FOR INSERT
  WITH CHECK (auth.uid() = student_id);

CREATE POLICY "Admins can view all tokens"
  ON public.tokens FOR SELECT
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update tokens"
  ON public.tokens FOR UPDATE
  USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for service_analytics
CREATE POLICY "Admins can view analytics"
  ON public.service_analytics FOR SELECT
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can manage analytics"
  ON public.service_analytics FOR ALL
  USING (public.has_role(auth.uid(), 'admin'));

-- Create trigger to auto-create profile on user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, student_id)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', 'User'),
    NEW.raw_user_meta_data->>'student_id'
  );
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Insert default services
INSERT INTO public.services (name, description, slots_per_hour, average_duration_minutes) VALUES
  ('Library', 'Book borrowing and returns', 20, 10),
  ('Counseling', 'Academic and personal counseling', 20, 30),
  ('Fees Payment', 'Tuition and other fee payments', 20, 15),
  ('Registration', 'Course registration and enrollment', 20, 20),
  ('ID Card Services', 'Student ID card issuance and renewal', 20, 10),
  ('Transcript Request', 'Academic transcript requests', 20, 15);

-- Function to generate unique token number
CREATE OR REPLACE FUNCTION public.generate_token_number(service_name TEXT)
RETURNS TEXT
LANGUAGE plpgsql
AS $$
DECLARE
  token_count INTEGER;
  token_prefix TEXT;
BEGIN
  -- Get first 3 letters of service name
  token_prefix := UPPER(LEFT(service_name, 3));
  
  -- Count tokens for today for this service
  SELECT COUNT(*) INTO token_count
  FROM public.tokens t
  JOIN public.services s ON t.service_id = s.id
  WHERE s.name = service_name
  AND DATE(t.created_at) = CURRENT_DATE;
  
  RETURN token_prefix || '-' || TO_CHAR(CURRENT_DATE, 'YYMMDD') || '-' || LPAD((token_count + 1)::TEXT, 4, '0');
END;
$$;

-- Enable realtime for tokens table
ALTER PUBLICATION supabase_realtime ADD TABLE public.tokens;