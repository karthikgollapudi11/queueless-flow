-- Add RLS policy to allow users to insert their own student role during signup
CREATE POLICY "Users can insert their own student role"
  ON public.user_roles FOR INSERT
  WITH CHECK (
    auth.uid() = user_id 
    AND role = 'student'
  );

-- Add policy to allow admins to insert any role for any user
CREATE POLICY "Admins can insert any role"
  ON public.user_roles FOR INSERT
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Add policy to allow admins to update roles
CREATE POLICY "Admins can update roles"
  ON public.user_roles FOR UPDATE
  USING (public.has_role(auth.uid(), 'admin'));