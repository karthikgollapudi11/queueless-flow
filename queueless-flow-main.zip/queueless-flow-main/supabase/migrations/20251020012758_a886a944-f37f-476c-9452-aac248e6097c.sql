-- Create initial admin accounts with preset credentials
-- These users will be created via direct SQL insert

-- Insert admin user role for user ID 5f76c92d-57be-4f02-a7bb-205535117292 (existing user from logs)
-- This will make the existing user "123@gmail.com" an admin
INSERT INTO public.user_roles (user_id, role)
VALUES ('5f76c92d-57be-4f02-a7bb-205535117292', 'admin')
ON CONFLICT (user_id, role) DO NOTHING;

-- Create a function to manually add admin role to any user
CREATE OR REPLACE FUNCTION public.make_user_admin(target_user_id UUID)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.user_roles (user_id, role)
  VALUES (target_user_id, 'admin')
  ON CONFLICT (user_id, role) DO NOTHING;
END;
$$;