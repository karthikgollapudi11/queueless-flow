-- Fix foreign key relationship for tokens to profiles
ALTER TABLE public.tokens DROP CONSTRAINT IF EXISTS tokens_student_id_fkey;
ALTER TABLE public.tokens 
  ADD CONSTRAINT tokens_student_id_fkey 
  FOREIGN KEY (student_id) 
  REFERENCES public.profiles(id) 
  ON DELETE CASCADE;