import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Loader2, ArrowLeft, Clock, CalendarClock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { format, addHours, setHours, setMinutes, isAfter, isBefore, startOfDay, addMinutes } from "date-fns";

interface TokenDisplayProps {
  serviceId: string;
  onBack: () => void;
}

const TokenDisplay = ({ serviceId, onBack }: TokenDisplayProps) => {
  const [service, setService] = useState<any>(null);
  const [currentToken, setCurrentToken] = useState<any>(null);
  const [selectedSlot, setSelectedSlot] = useState<string>("");
  const [availableSlots, setAvailableSlots] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchData();
    setupRealtimeSubscription();
  }, [serviceId]);

  const setupRealtimeSubscription = () => {
    const channel = supabase
      .channel('token-updates')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'tokens',
          filter: `service_id=eq.${serviceId}`,
        },
        () => {
          fetchCurrentToken();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const fetchData = async () => {
    try {
      // Fetch service
      const { data: serviceData, error: serviceError } = await supabase
        .from("services")
        .select("*")
        .eq("id", serviceId)
        .single();

      if (serviceError) throw serviceError;
      setService(serviceData);

      // Fetch current token
      await fetchCurrentToken();

      // Generate available slots
      generateAvailableSlots(serviceData);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchCurrentToken = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data: tokenData } = await supabase
      .from("tokens")
      .select("*")
      .eq("student_id", user.id)
      .eq("service_id", serviceId)
      .in("status", ["pending", "in_progress"])
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    setCurrentToken(tokenData);
  };

  const generateAvailableSlots = async (serviceData: any) => {
    const today = startOfDay(new Date());
    const slots: string[] = [];
    
    const startHour = serviceData.working_hours_start;
    const endHour = serviceData.working_hours_end;
    const slotsPerHour = serviceData.slots_per_hour;
    const minutesPerSlot = 60 / slotsPerHour;

    // Fetch existing bookings for today
    const { data: existingTokens } = await supabase
      .from("tokens")
      .select("slot_time")
      .eq("service_id", serviceId)
      .gte("slot_time", today.toISOString())
      .lt("slot_time", addHours(today, 24).toISOString());

    const bookedSlots = new Set(
      existingTokens?.map((t) => t.slot_time) || []
    );

    for (let hour = startHour; hour < endHour; hour++) {
      for (let slot = 0; slot < slotsPerHour; slot++) {
        const minutes = slot * minutesPerSlot;
        let slotTime = setHours(today, hour);
        slotTime = setMinutes(slotTime, minutes);

        if (isAfter(slotTime, new Date()) && !bookedSlots.has(slotTime.toISOString())) {
          slots.push(slotTime.toISOString());
        }
      }
    }

    setAvailableSlots(slots);
  };

  const createToken = async () => {
    if (!selectedSlot) {
      toast({
        title: "Select a slot",
        description: "Please select a time slot",
        variant: "destructive",
      });
      return;
    }

    setCreating(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      // Count pending tokens before this slot
      const { data: pendingTokens, error: countError } = await supabase
        .from("tokens")
        .select("id", { count: "exact" })
        .eq("service_id", serviceId)
        .in("status", ["pending", "in_progress"])
        .lt("slot_time", selectedSlot);

      if (countError) throw countError;

      const waitingTokens = pendingTokens?.length || 0;
      const estimatedWait = waitingTokens * service.average_duration_minutes;

      // Generate token number
      const { data: tokenNumber, error: fnError } = await supabase
        .rpc("generate_token_number", { service_name: service.name });

      if (fnError) throw fnError;

      // Create token
      const { error } = await supabase.from("tokens").insert({
        token_number: tokenNumber,
        student_id: user.id,
        service_id: serviceId,
        slot_time: selectedSlot,
        estimated_wait_minutes: estimatedWait,
        status: "pending",
      });

      if (error) throw error;

      toast({
        title: "Token created!",
        description: "Your token has been generated successfully.",
      });

      fetchCurrentToken();
    } catch (error: any) {
      toast({
        title: "Error creating token",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setCreating(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-pending text-warning-foreground";
      case "in_progress":
        return "bg-in-progress text-accent-foreground";
      case "completed":
        return "bg-completed text-success-foreground";
      default:
        return "bg-muted";
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <Button variant="ghost" onClick={onBack}>
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Services
      </Button>

      <Card>
        <CardHeader>
          <CardTitle>{service?.name}</CardTitle>
          <CardDescription>{service?.description}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {currentToken ? (
            <div className="space-y-4">
              <div className="text-center p-6 bg-primary/5 rounded-lg space-y-4">
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">Your Token</p>
                  <p className="text-4xl font-bold text-primary">{currentToken.token_number}</p>
                </div>
                <Badge className={getStatusColor(currentToken.status)}>
                  {currentToken.status.replace("_", " ").toUpperCase()}
                </Badge>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center gap-2 p-4 bg-secondary/50 rounded-lg">
                  <CalendarClock className="h-5 w-5 text-primary" />
                  <div>
                    <p className="text-xs text-muted-foreground">Slot Time</p>
                    <p className="font-semibold">{format(new Date(currentToken.slot_time), "h:mm a")}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 p-4 bg-secondary/50 rounded-lg">
                  <Clock className="h-5 w-5 text-primary" />
                  <div>
                    <p className="text-xs text-muted-foreground">Est. Wait</p>
                    <p className="font-semibold">{currentToken.estimated_wait_minutes} min</p>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="slot">Select Time Slot</Label>
                <Select value={selectedSlot} onValueChange={setSelectedSlot}>
                  <SelectTrigger id="slot">
                    <SelectValue placeholder="Choose your slot" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableSlots.length > 0 ? (
                      availableSlots.map((slot) => (
                        <SelectItem key={slot} value={slot}>
                          {format(new Date(slot), "h:mm a")}
                        </SelectItem>
                      ))
                    ) : (
                      <SelectItem value="none" disabled>
                        No slots available today
                      </SelectItem>
                    )}
                  </SelectContent>
                </Select>
              </div>

              <Button
                className="w-full"
                onClick={createToken}
                disabled={creating || !selectedSlot || availableSlots.length === 0}
              >
                {creating && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Generate Token
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default TokenDisplay;
