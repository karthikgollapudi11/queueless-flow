import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, TrendingUp, Clock, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ServiceWithAnalytics {
  id: string;
  name: string;
  average_duration_minutes: number;
  service_analytics: {
    total_tokens: number;
    completed_tokens: number;
    average_duration_minutes: number | null;
  }[];
}

const ServiceAnalytics = () => {
  const [services, setServices] = useState<ServiceWithAnalytics[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchAnalytics();
  }, []);

  const fetchAnalytics = async () => {
    try {
      const today = new Date().toISOString().split("T")[0];

      const { data, error } = await supabase
        .from("services")
        .select(`
          id,
          name,
          average_duration_minutes,
          service_analytics!inner (
            total_tokens,
            completed_tokens,
            average_duration_minutes
          )
        `)
        .eq("service_analytics.date", today);

      if (error) throw error;
      setServices(data || []);
    } catch (error: any) {
      toast({
        title: "Error loading analytics",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (services.length === 0) {
    return (
      <Card>
        <CardContent className="pt-6 text-center text-muted-foreground">
          <p>No analytics data available for today.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {services.map((service) => {
        const analytics = service.service_analytics[0] || {
          total_tokens: 0,
          completed_tokens: 0,
          average_duration_minutes: null,
        };

        return (
          <Card key={service.id}>
            <CardHeader>
              <CardTitle>{service.name}</CardTitle>
              <CardDescription>Today's Performance</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-muted-foreground text-sm">
                    <TrendingUp className="h-4 w-4" />
                    <span>Total Tokens</span>
                  </div>
                  <p className="text-2xl font-bold">{analytics.total_tokens}</p>
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-muted-foreground text-sm">
                    <CheckCircle className="h-4 w-4" />
                    <span>Completed</span>
                  </div>
                  <p className="text-2xl font-bold text-success">
                    {analytics.completed_tokens}
                  </p>
                </div>
              </div>

              <div className="pt-4 border-t space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Avg. Duration (Today)</span>
                  <span className="font-semibold">
                    {analytics.average_duration_minutes
                      ? `${analytics.average_duration_minutes} min`
                      : "N/A"}
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Est. Duration</span>
                  <span className="font-semibold">
                    {service.average_duration_minutes} min
                  </span>
                </div>
              </div>

              {analytics.completed_tokens > 0 && (
                <div className="pt-4 border-t">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Completion Rate</span>
                    <span className="font-bold text-primary">
                      {Math.round((analytics.completed_tokens / analytics.total_tokens) * 100)}%
                    </span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
};

export default ServiceAnalytics;
