import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, Clock, User, Play, CheckCircle2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

interface Token {
  id: string;
  token_number: string;
  status: string;
  slot_time: string;
  estimated_wait_minutes: number;
  issued_at: string;
  started_at: string | null;
  profiles: {
    full_name: string;
    student_id: string | null;
  };
  services: {
    name: string;
  };
}

const ActiveTokens = () => {
  const [tokens, setTokens] = useState<Token[]>([]);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    fetchTokens();
    setupRealtimeSubscription();
  }, []);

  const setupRealtimeSubscription = () => {
    const channel = supabase
      .channel('active-tokens')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'tokens',
        },
        () => {
          fetchTokens();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const fetchTokens = async () => {
    try {
      const { data, error } = await supabase
        .from("tokens")
        .select(`
          *,
          profiles (full_name, student_id),
          services (name)
        `)
        .in("status", ["pending", "in_progress"])
        .order("slot_time", { ascending: true });

      if (error) throw error;
      setTokens(data || []);
    } catch (error: any) {
      toast({
        title: "Error loading tokens",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const updateTokenStatus = async (tokenId: string, newStatus: string) => {
    setUpdating(tokenId);
    try {
      const updateData: any = { status: newStatus };
      
      if (newStatus === "in_progress") {
        updateData.started_at = new Date().toISOString();
      } else if (newStatus === "completed") {
        updateData.completed_at = new Date().toISOString();
      }

      const { error } = await supabase
        .from("tokens")
        .update(updateData)
        .eq("id", tokenId);

      if (error) throw error;

      // Update analytics
      if (newStatus === "completed") {
        await updateServiceAnalytics(tokenId);
      }

      toast({
        title: "Token updated",
        description: `Status changed to ${newStatus}`,
      });
    } catch (error: any) {
      toast({
        title: "Error updating token",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setUpdating(null);
    }
  };

  const updateServiceAnalytics = async (tokenId: string) => {
    try {
      const { data: token } = await supabase
        .from("tokens")
        .select("service_id, started_at, completed_at")
        .eq("id", tokenId)
        .single();

      if (!token || !token.started_at || !token.completed_at) return;

      const duration = Math.round(
        (new Date(token.completed_at).getTime() - new Date(token.started_at).getTime()) / 60000
      );

      const today = format(new Date(), "yyyy-MM-dd");

      const { data: existing } = await supabase
        .from("service_analytics")
        .select("*")
        .eq("service_id", token.service_id)
        .eq("date", today)
        .single();

      if (existing) {
        const newCompleted = existing.completed_tokens + 1;
        const newAverage = Math.round(
          ((existing.average_duration_minutes || 0) * existing.completed_tokens + duration) / newCompleted
        );

        await supabase
          .from("service_analytics")
          .update({
            completed_tokens: newCompleted,
            average_duration_minutes: newAverage,
          })
          .eq("id", existing.id);
      } else {
        await supabase.from("service_analytics").insert({
          service_id: token.service_id,
          date: today,
          total_tokens: 1,
          completed_tokens: 1,
          average_duration_minutes: duration,
        });
      }
    } catch (error) {
      console.error("Error updating analytics:", error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-pending text-warning-foreground";
      case "in_progress":
        return "bg-in-progress text-accent-foreground";
      default:
        return "bg-muted";
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (tokens.length === 0) {
    return (
      <Card>
        <CardContent className="pt-6 text-center text-muted-foreground">
          <p>No active tokens at the moment.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {tokens.map((token) => (
          <Card key={token.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-xl">{token.token_number}</CardTitle>
                  <CardDescription>{token.services.name}</CardDescription>
                </div>
                <Badge className={getStatusColor(token.status)}>
                  {token.status.replace("_", " ").toUpperCase()}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4 text-muted-foreground" />
                  <span className="font-medium">{token.profiles.full_name}</span>
                  {token.profiles.student_id && (
                    <span className="text-muted-foreground">({token.profiles.student_id})</span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span>Slot: {format(new Date(token.slot_time), "h:mm a")}</span>
                </div>
                <div className="text-muted-foreground text-xs">
                  Issued: {format(new Date(token.issued_at), "MMM dd, h:mm a")}
                </div>
              </div>

              <div className="flex gap-2">
                {token.status === "pending" && (
                  <Button
                    className="flex-1"
                    onClick={() => updateTokenStatus(token.id, "in_progress")}
                    disabled={updating === token.id}
                  >
                    {updating === token.id ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <Play className="mr-2 h-4 w-4" />
                    )}
                    Start Service
                  </Button>
                )}
                {token.status === "in_progress" && (
                  <Button
                    className="flex-1"
                    onClick={() => updateTokenStatus(token.id, "completed")}
                    disabled={updating === token.id}
                  >
                    {updating === token.id ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <CheckCircle2 className="mr-2 h-4 w-4" />
                    )}
                    Complete
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default ActiveTokens;
