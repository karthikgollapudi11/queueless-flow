import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, Calendar, Clock, User } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface Token {
  id: string;
  token_number: string;
  status: string;
  slot_time: string;
  issued_at: string;
  completed_at: string | null;
  profiles: {
    full_name: string;
    student_id: string | null;
  };
  services: {
    name: string;
  };
}

const TokenHistory = () => {
  const [tokens, setTokens] = useState<Token[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchCompletedTokens();
  }, []);

  const fetchCompletedTokens = async () => {
    try {
      const { data, error } = await supabase
        .from("tokens")
        .select(`
          *,
          profiles (full_name, student_id),
          services (name)
        `)
        .eq("status", "completed")
        .order("completed_at", { ascending: false })
        .limit(50);

      if (error) throw error;
      setTokens(data || []);
    } catch (error: any) {
      toast({
        title: "Error loading history",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (tokens.length === 0) {
    return (
      <Card>
        <CardContent className="pt-6 text-center text-muted-foreground">
          <p>No completed tokens yet.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="pt-6">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Token</TableHead>
              <TableHead>Service</TableHead>
              <TableHead>Student</TableHead>
              <TableHead>Slot Time</TableHead>
              <TableHead>Completed At</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {tokens.map((token) => (
              <TableRow key={token.id}>
                <TableCell className="font-medium">{token.token_number}</TableCell>
                <TableCell>{token.services.name}</TableCell>
                <TableCell>
                  <div className="flex flex-col">
                    <span className="font-medium">{token.profiles.full_name}</span>
                    {token.profiles.student_id && (
                      <span className="text-xs text-muted-foreground">
                        {token.profiles.student_id}
                      </span>
                    )}
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-1 text-sm">
                    <Clock className="h-3 w-3 text-muted-foreground" />
                    {format(new Date(token.slot_time), "h:mm a")}
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-1 text-sm">
                    <Calendar className="h-3 w-3 text-muted-foreground" />
                    {token.completed_at
                      ? format(new Date(token.completed_at), "MMM dd, h:mm a")
                      : "N/A"}
                  </div>
                </TableCell>
                <TableCell>
                  <Badge className="bg-completed text-success-foreground">
                    COMPLETED
                  </Badge>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
};

export default TokenHistory;
