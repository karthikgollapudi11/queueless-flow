import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { ShieldCheck, Loader2 } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

interface Profile {
  id: string;
  full_name: string;
  student_id: string;
  user_roles: { role: string }[];
}

const UserManagement = () => {
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [promotingId, setPromotingId] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    fetchProfiles();
  }, []);

  const fetchProfiles = async () => {
    try {
      const { data: profilesData, error: profilesError } = await supabase
        .from("profiles")
        .select("id, full_name, student_id")
        .order("full_name");

      if (profilesError) throw profilesError;

      const { data: rolesData, error: rolesError } = await supabase
        .from("user_roles")
        .select("user_id, role");

      if (rolesError) throw rolesError;

      const profilesWithRoles = (profilesData || []).map(profile => ({
        ...profile,
        user_roles: (rolesData || [])
          .filter(role => role.user_id === profile.id)
          .map(role => ({ role: role.role }))
      }));

      setProfiles(profilesWithRoles);
    } catch (error: any) {
      toast({
        title: "Error loading users",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const promoteToAdmin = async (userId: string) => {
    setPromotingId(userId);
    try {
      const { error } = await supabase.rpc("make_user_admin", {
        target_user_id: userId,
      });

      if (error) throw error;

      toast({
        title: "Success",
        description: "User promoted to admin",
      });

      await fetchProfiles();
    } catch (error: any) {
      toast({
        title: "Failed to promote user",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setPromotingId(null);
    }
  };

  const isAdmin = (profile: Profile) => {
    return profile.user_roles.some((role) => role.role === "admin");
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-8">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ShieldCheck className="h-5 w-5" />
          User Management
        </CardTitle>
        <CardDescription>
          Promote users to admin status
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Student ID</TableHead>
              <TableHead>Role</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {profiles.map((profile) => (
              <TableRow key={profile.id}>
                <TableCell className="font-medium">{profile.full_name}</TableCell>
                <TableCell>{profile.student_id || "N/A"}</TableCell>
                <TableCell>
                  {isAdmin(profile) ? (
                    <Badge variant="default">Admin</Badge>
                  ) : (
                    <Badge variant="secondary">Student</Badge>
                  )}
                </TableCell>
                <TableCell>
                  {!isAdmin(profile) && (
                    <Button
                      size="sm"
                      onClick={() => promoteToAdmin(profile.id)}
                      disabled={promotingId === profile.id}
                    >
                      {promotingId === profile.id ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        "Promote to Admin"
                      )}
                    </Button>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
};

export default UserManagement;