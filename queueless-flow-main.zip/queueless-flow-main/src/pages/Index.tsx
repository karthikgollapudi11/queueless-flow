import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { GraduationCap, ShieldCheck, Clock, Users, TrendingUp } from "lucide-react";

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-background">
      <header className="container mx-auto px-4 py-6">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
            <Clock className="h-6 w-6 text-primary" />
          </div>
          <h1 className="text-3xl font-bold text-primary">Queueless</h1>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-6xl mx-auto space-y-12">
          {/* Hero Section */}
          <div className="text-center space-y-6">
            <h2 className="text-5xl font-bold leading-tight">
              Smart Queue Management
              <br />
              <span className="text-primary">Made Simple</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Book your slots, track your tokens, and say goodbye to long waiting lines
            </p>
          </div>

          {/* Login Cards */}
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <Card className="hover:shadow-xl transition-all border-2 hover:border-primary/50">
              <CardHeader className="text-center space-y-4">
                <div className="mx-auto h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
                  <GraduationCap className="h-10 w-10 text-primary" />
                </div>
                <CardTitle className="text-2xl">Student Portal</CardTitle>
                <CardDescription className="text-base">
                  Book slots and manage your service tokens
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Link to="/student-auth">
                  <Button className="w-full h-12 text-lg">
                    Student Login
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="hover:shadow-xl transition-all border-2 hover:border-primary/50">
              <CardHeader className="text-center space-y-4">
                <div className="mx-auto h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
                  <ShieldCheck className="h-10 w-10 text-primary" />
                </div>
                <CardTitle className="text-2xl">Admin Portal</CardTitle>
                <CardDescription className="text-base">
                  Manage queues and monitor service analytics
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Link to="/admin-auth">
                  <Button className="w-full h-12 text-lg" variant="outline">
                    Admin Login
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>

          {/* Features */}
          <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto pt-12">
            <Card className="text-center">
              <CardContent className="pt-6 space-y-3">
                <div className="mx-auto h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <Clock className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold text-lg">Slot-Based Booking</h3>
                <p className="text-sm text-muted-foreground">
                  Book your preferred time slot from 9 AM to 5 PM
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="pt-6 space-y-3">
                <div className="mx-auto h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <Users className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold text-lg">Real-Time Updates</h3>
                <p className="text-sm text-muted-foreground">
                  Track your token status and estimated wait time live
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="pt-6 space-y-3">
                <div className="mx-auto h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <TrendingUp className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold text-lg">Service Analytics</h3>
                <p className="text-sm text-muted-foreground">
                  Admins can monitor performance and optimize services
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Index;
